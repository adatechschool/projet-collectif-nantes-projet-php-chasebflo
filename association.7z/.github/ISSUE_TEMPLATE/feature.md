---
name: Feature
about: Décrivez une fonctionnalité de pour votre projet
title: "[Feature]"
labels: enhancement
assignees: ''

---

**Donnez un titre à votre feature**
[Feature][Catégorie] Titre
Nous vous invitons à regrouper les fonctionnalités par grandes catégories de
votre projet.

**Décrivez-la**
Quels sont les critères d'acceptation et de rejet de cette fonctionnalité ?
Que doit-elle faire et ne pas faire, précisément ?
Ces critère devront être remplis avant de passer la carte en "Done".

**Ajoutez une checklist**
Vous pouvez ajouter une liste de choses à réaliser avec des cases à cocher,
afin de suivre plus précisément l'état d'avancement de votre fonctionnalité.
Toutes les cases doivent être remplies pour passer la carte en "Done".