---
name: User story
about: Créez une user story pour votre projet
title: "[US]"
labels: enhancement
assignees: ''

---

**Décrivez votre user story.**
En tant que [persona], je souhaite [souhait] afin de [but]

**Donnez lui un titre approprié**
[Type : parmi US, Bug Fix, Refacto] Titre (Story points) (Value points)
