<?php
$host = "localhost";
$dbname = "gestion_collectes";
$username = "root";
$password = "";
?>